const db = uniCloud.database()

module.exports = {
	_before: function () {
		// 这里是云函数的前置方法，可以在这里统一处理一些逻辑
	},

	/**
	 * 云函数主入口，根据action分发到对应方法
	 */
	async main(event, context) {
		console.log('[天气云函数] 收到请求:', JSON.stringify(event, null, 2))
		console.log('[天气云函数] 请求上下文:', {
			requestId: context.requestId,
			functionName: context.functionName,
			functionVersion: context.functionVersion,
			memory: context.memory,
			timeout: context.timeout
		})
		
		const { action, ...params } = event
		
		try {
			console.log('[天气云函数] 解析操作类型:', action)
			console.log('[天气云函数] 操作参数:', JSON.stringify(params, null, 2))
			
			let result
			const startTime = Date.now()
			
			switch (action) {
				case 'getWeather':
					console.log('[天气云函数] 执行天气查询')
					result = await this.getWeather(params)
					break
				case 'getWeatherByCityName':
					console.log('[天气云函数] 执行城市名称天气查询')
					result = await this.getWeatherByCityName(params)
					break
				case 'getBatchWeather':
					console.log('[天气云函数] 执行批量天气查询')
					result = await this.getBatchWeather(params)
					break
				default:
					console.error('[天气云函数] 未知的action:', action)
					return {
						code: 400,
						message: '未知的操作类型',
						data: null
					}
			}
			
			const endTime = Date.now()
			const duration = endTime - startTime
			
			console.log(`[天气云函数] 操作执行完成，耗时: ${duration}ms`)
			console.log('[天气云函数] 返回结果状态码:', result.code)
			
			if (result.code === 200) {
				console.log('[天气云函数] 操作成功')
				if (result.data) {
					console.log('[天气云函数] 返回数据类型:', typeof result.data)
					if (Array.isArray(result.data)) {
						console.log('[天气云函数] 返回数据数量:', result.data.length)
					}
				}
			} else {
				console.warn('[天气云函数] 操作失败:', result.message)
			}
			
			return result
		} catch (error) {
			console.error('[天气云函数] 处理请求时发生异常:', error)
			console.error('[天气云函数] 异常堆栈:', error.stack)
			console.error('[天气云函数] 异常详情:', {
				name: error.name,
				message: error.message,
				code: error.code
			})
			return {
				code: 500,
				message: '天气服务异常: ' + error.message,
				data: null
			}
		}
	},

	/**
	 * 获取天气信息
	 * @param {Object} params
	 * @param {String} params.city - 城市编码或城市名称
	 * @param {String} params.extensions - 气象类型 base:实时天气 all:预报天气
	 */
	async getWeather(params) {
		console.log('[天气云函数-天气查询] 开始获取天气信息:', JSON.stringify(params, null, 2))
		
		try {
			const { city = '110000', extensions = 'all' } = params
			
			console.log('[天气云函数-天气查询] 查询城市:', city)
			console.log('[天气云函数-天气查询] 查询类型:', extensions)
			
			// 验证extensions参数 (官方文档：base/all)
			if (!['base', 'all'].includes(extensions)) {
				console.error('[天气云函数-天气查询] extensions参数无效:', extensions)
				return {
					code: 400,
					message: 'extensions参数必须是base或all',
					data: null
				}
			}
			console.log('[天气云函数-天气查询] 参数验证通过')
			
			// 高德地图API Key (使用uni-config-center)
			console.log('[天气云函数-天气查询] 开始获取API配置')
			const createConfig = require('uni-config-center')
			const weatherConfig = createConfig({
				pluginId: 'a-weather',
				defaultConfig: {
					amapApiKey: 'c79c3a382a1a0ee9d06889d1db95f7bd'
				}
			})
			
			const apiKey = weatherConfig.config('amapApiKey')
			console.log('[天气云函数-天气查询] API Key配置状态:', apiKey ? '已配置' : '未配置')
			
			if (!apiKey) {
				console.error('[天气云函数-天气查询] 高德地图API Key未配置')
				return {
					code: 500,
					message: '天气服务配置错误',
					data: null
				}
			}
			
			// 构建请求URL (按照官方文档格式)
			const url = `https://restapi.amap.com/v3/weather/weatherInfo?key=${apiKey}&city=${encodeURIComponent(city)}&extensions=${extensions}&output=JSON`
			console.log('[天气云函数-天气查询] 请求URL:', url.replace(apiKey, '***'))
			
			// 发起HTTP请求
			console.log('[天气云函数-天气查询] 开始发起API请求')
			const requestStartTime = Date.now()
			const response = await uniCloud.httpclient.request(url, {
				method: 'GET',
				timeout: 10000,
				dataType: 'json'
			})
			const requestEndTime = Date.now()
			
			console.log(`[天气云函数-天气查询] API请求完成，耗时: ${requestEndTime - requestStartTime}ms`)
			console.log('[天气云函数-天气查询] API响应状态:', response.status)
			console.log('[天气云函数-天气查询] API响应数据:', JSON.stringify(response.data, null, 2))
			
			if (response.status !== 200) {
				console.error('[天气云函数] API请求失败，状态码:', response.status)
				return {
					code: 500,
					message: '天气服务请求失败',
					data: null
				}
			}
			
			const weatherData = response.data
			
			// 检查API返回状态 (官方文档：status为1表示成功，0表示失败)
			if (weatherData.status !== '1') {
				console.error('[天气云函数] 高德API返回错误:', {
					status: weatherData.status,
					info: weatherData.info,
					infocode: weatherData.infocode
				})
				return {
					code: 500,
					message: weatherData.info || '天气数据获取失败',
					data: {
						infocode: weatherData.infocode,
						originalError: weatherData
					}
				}
			}
			
			// 格式化天气数据
			const formattedData = this.formatWeatherData(weatherData, extensions)
			
			console.log('[天气云函数] 格式化后的数据:', formattedData)
			
			return {
				code: 200,
				message: '获取成功',
				data: formattedData
			}
			
		} catch (error) {
			console.error('[天气云函数] 获取天气信息失败:', error)
			return {
				code: 500,
				message: '天气服务异常: ' + error.message,
				data: null
			}
		}
	},

	/**
	 * 根据城市名称获取天气信息
	 * @param {Object} params
	 * @param {String} params.cityName - 城市名称
	 * @param {String} params.extensions - 气象类型
	 */
	async getWeatherByCityName(params) {
		console.log('[天气云函数] 根据城市名称获取天气:', params)
		
		try {
			const { cityName, extensions = 'all' } = params
			
			if (!cityName) {
				return {
					code: 400,
					message: '城市名称不能为空',
					data: null
				}
			}
			
			// 直接使用城市名称调用天气API
			return await this.getWeather({
				city: cityName,
				extensions: extensions
			})
			
		} catch (error) {
			console.error('[天气云函数] 根据城市名称获取天气失败:', error)
			return {
				code: 500,
				message: '天气服务异常: ' + error.message,
				data: null
			}
		}
	},

	/**
	 * 批量获取多个城市的天气信息
	 * @param {Object} params
	 * @param {Array} params.cities - 城市列表 [{name: '北京', code: '110000'}, ...]
	 * @param {String} params.extensions - 气象类型
	 */
	async getBatchWeather(params) {
		console.log('[天气云函数] 批量获取天气信息:', params)
		
		try {
			const { cities = [], extensions = 'base' } = params
			
			if (!Array.isArray(cities) || cities.length === 0) {
				return {
					code: 400,
					message: '城市列表不能为空',
					data: null
				}
			}
			
			// 限制批量查询数量
			if (cities.length > 10) {
				return {
					code: 400,
					message: '批量查询城市数量不能超过10个',
					data: null
				}
			}
			
			const results = []
			
			// 并发请求所有城市的天气
			const promises = cities.map(async (cityInfo) => {
				try {
					const city = cityInfo.code || cityInfo.name
					const result = await this.getWeather({ city, extensions })
					return {
						city: cityInfo.name || city,
						...result
					}
				} catch (error) {
					console.error(`[天气云函数] 获取${cityInfo.name}天气失败:`, error)
					return {
						city: cityInfo.name || cityInfo.code,
						code: 500,
						message: '获取失败',
						data: null
					}
				}
			})
			
			const weatherResults = await Promise.all(promises)
			
			return {
				code: 200,
				message: '批量获取完成',
				data: weatherResults
			}
			
		} catch (error) {
			console.error('[天气云函数] 批量获取天气失败:', error)
			return {
				code: 500,
				message: '批量天气服务异常: ' + error.message,
				data: null
			}
		}
	},

	/**
	 * 格式化天气数据
	 * @param {Object} weatherData - 高德API返回的原始数据
	 * @param {String} extensions - 请求类型
	 */
	formatWeatherData(weatherData, extensions) {
		console.log('[天气云函数] 开始格式化天气数据')
		
		try {
			if (extensions === 'base') {
				// 实时天气数据格式化
				const live = weatherData.lives?.[0]
				if (!live) {
					throw new Error('实时天气数据为空')
				}
				
				return {
					type: 'live',
					city: live.city,
					province: live.province,
					adcode: live.adcode,
					weather: live.weather,
					temperature: live.temperature,
					winddirection: live.winddirection,
					windpower: live.windpower,
					humidity: live.humidity,
					reporttime: live.reporttime,
					formatted: {
						location: `${live.province} ${live.city}`,
						condition: live.weather,
						temp: `${live.temperature}°C`,
						humidity: `${live.humidity}%`,
						wind: `${live.winddirection}风 ${live.windpower}级`,
						updateTime: live.reporttime
					}
				}
			} else {
				// 预报天气数据格式化
				const forecast = weatherData.forecasts?.[0]
				if (!forecast) {
					throw new Error('预报天气数据为空')
				}
				
				const casts = forecast.casts || []
				const formattedCasts = casts.map((cast, index) => {
					const date = new Date(cast.date)
					const dayNames = ['今天', '明天', '后天']
					const dayName = index < 3 ? dayNames[index] : `${date.getMonth() + 1}月${date.getDate()}日`
					
					return {
						date: cast.date,
						dayName: dayName,
						week: cast.week,
						dayweather: cast.dayweather,
						nightweather: cast.nightweather,
						daytemp: cast.daytemp,
						nighttemp: cast.nighttemp,
						daywind: cast.daywind,
						nightwind: cast.nightwind,
						daypower: cast.daypower,
						nightpower: cast.nightpower,
						formatted: {
							date: `${date.getMonth() + 1}月${date.getDate()}日`,
							dayName: dayName,
							condition: cast.dayweather,
							tempRange: `${cast.nighttemp}°C ~ ${cast.daytemp}°C`,
							wind: `${cast.daywind} ${cast.daypower}级`
						}
					}
				})
				
				return {
					type: 'forecast',
					city: forecast.city,
					province: forecast.province,
					adcode: forecast.adcode,
					reporttime: forecast.reporttime,
					casts: formattedCasts,
					today: formattedCasts[0] || null,
					tomorrow: formattedCasts[1] || null
				}
			}
		} catch (error) {
			console.error('[天气云函数] 格式化天气数据失败:', error)
			throw error
		}
	}
} 