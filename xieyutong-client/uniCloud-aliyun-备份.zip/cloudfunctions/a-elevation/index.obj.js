module.exports = {
	/**
	 * 云函数入口
	 * @param {Object} event 
	 * @param {Object} context 
	 */
	async main(event, context) {
		console.log('[海拔云函数] 接收到请求:', JSON.stringify(event, null, 2))
		console.log('[海拔云函数] 请求上下文:', {
			requestId: context.requestId,
			functionName: context.functionName,
			functionVersion: context.functionVersion,
			memory: context.memory,
			timeout: context.timeout
		})
		
		const { action, ...params } = event
		
		try {
			console.log('[海拔云函数] 解析操作类型:', action)
			console.log('[海拔云函数] 操作参数:', JSON.stringify(params, null, 2))
			
			let result
			const startTime = Date.now()
			
			switch (action) {
				case 'getElevationForLocations':
					console.log('[海拔云函数] 执行位置海拔查询')
					result = await this.getElevationForLocations(params)
					break
				case 'getElevationAlongPath':
					console.log('[海拔云函数] 执行路径海拔查询')
					result = await this.getElevationAlongPath(params)
					break
				case 'getBatchElevation':
					console.log('[海拔云函数] 执行批量海拔查询')
					result = await this.getBatchElevation(params)
					break
				default:
					console.error('[海拔云函数] 未知的操作类型:', action)
					return {
						code: 400,
						message: '不支持的操作类型',
						data: null
					}
			}
			
			const endTime = Date.now()
			const duration = endTime - startTime
			
			console.log(`[海拔云函数] 操作执行完成，耗时: ${duration}ms`)
			console.log('[海拔云函数] 返回结果状态码:', result.code)
			
			if (result.code === 200) {
				console.log('[海拔云函数] 操作成功')
				if (result.data && result.data.results) {
					console.log('[海拔云函数] 返回数据点数量:', result.data.results.length)
				}
			} else {
				console.warn('[海拔云函数] 操作失败:', result.message)
			}
			
			return result
		} catch (error) {
			console.error('[海拔云函数] 处理请求时发生异常:', error)
			console.error('[海拔云函数] 异常堆栈:', error.stack)
			console.error('[海拔云函数] 异常详情:', {
				name: error.name,
				message: error.message,
				code: error.code
			})
			return {
				code: 500,
				message: '海拔服务异常: ' + error.message,
				data: null
			}
		}
	},

	/**
	 * 获取指定位置的海拔信息
	 * @param {Object} params
	 * @param {Array} params.locations - 位置列表 [{lat: 36.579, lng: -118.292}, ...]
	 */
	async getElevationForLocations(params) {
		console.log('[海拔云函数-位置查询] 开始获取位置海拔信息:', JSON.stringify(params, null, 2))
		
		try {
			const { locations = [] } = params
			
			console.log('[海拔云函数-位置查询] 位置列表长度:', locations.length)
			
			if (!Array.isArray(locations) || locations.length === 0) {
				console.warn('[海拔云函数-位置查询] 位置列表为空或格式错误')
				return {
					code: 400,
					message: '位置列表不能为空',
					data: null
				}
			}
			
			// 验证位置数据格式
			console.log('[海拔云函数-位置查询] 开始验证位置数据格式')
			for (let i = 0; i < locations.length; i++) {
				const location = locations[i]
				console.log(`[海拔云函数-位置查询] 验证位置 ${i + 1}:`, location)
				if (!location.lat || !location.lng) {
					console.error(`[海拔云函数-位置查询] 位置 ${i + 1} 格式错误:`, location)
					return {
						code: 400,
						message: `位置 ${i + 1} 的经纬度格式不正确`,
						data: null
					}
				}
			}
			console.log('[海拔云函数-位置查询] 位置数据格式验证通过')
			
					// 获取Google Maps API Key (使用uni-config-center)
		console.log('[海拔云函数-位置查询] 开始获取API配置')
		const createConfig = require('uni-config-center')
		const elevationConfig = createConfig({
			pluginId: 'a-elevation',
			defaultConfig: {
				googleMapsApiKey: 'AIzaSyC7HihytH-JPVOtshAWcd-6-cpPFT7Y3M4'
			}
		})
		
		const apiKey = elevationConfig.config('googleMapsApiKey')
		console.log('[海拔云函数-位置查询] API Key配置状态:', apiKey ? '已配置' : '未配置')
		
		if (!apiKey) {
			console.error('[海拔云函数-位置查询] Google Maps API Key未配置')
			return {
				code: 500,
				message: '海拔服务配置错误',
				data: null
			}
		}
		
		// 构建位置参数字符串
			const locationsParam = locations.map(loc => `${loc.lat},${loc.lng}`).join('|')
			console.log('[海拔云函数-位置查询] 构建位置参数:', locationsParam)
			
			// 构建请求URL
			const url = `https://maps.googleapis.com/maps/api/elevation/json?locations=${locationsParam}&key=${apiKey}`
			console.log('[海拔云函数-位置查询] 请求URL:', url.replace(apiKey, '***'))
			
			// 发起HTTP请求
			console.log('[海拔云函数-位置查询] 开始发起API请求')
			const requestStartTime = Date.now()
			const response = await uniCloud.httpclient.request(url, {
				method: 'GET',
				timeout: 10000,
				dataType: 'json'
			})
			const requestEndTime = Date.now()
			
			console.log(`[海拔云函数-位置查询] API请求完成，耗时: ${requestEndTime - requestStartTime}ms`)
			console.log('[海拔云函数-位置查询] API响应状态:', response.status)
			console.log('[海拔云函数-位置查询] API响应数据:', JSON.stringify(response.data, null, 2))
			
			if (response.status !== 200) {
				console.error('[海拔云函数] API请求失败，状态码:', response.status)
				return {
					code: 500,
					message: '海拔服务请求失败',
					data: null
				}
			}
			
			const elevationData = response.data
			
			// 检查API返回状态
			if (elevationData.status !== 'OK') {
				console.error('[海拔云函数] Google API返回错误:', {
					status: elevationData.status,
					error_message: elevationData.error_message
				})
				return {
					code: 500,
					message: this.getErrorMessage(elevationData.status),
					data: {
						status: elevationData.status,
						error_message: elevationData.error_message,
						originalError: elevationData
					}
				}
			}
			
			// 格式化海拔数据
			const formattedData = this.formatElevationData(elevationData.results, 'locations')
			
			console.log('[海拔云函数] 格式化后的数据:', formattedData)
			
			return {
				code: 200,
				message: '获取成功',
				data: formattedData
			}
			
		} catch (error) {
			console.error('[海拔云函数] 获取位置海拔信息失败:', error)
			return {
				code: 500,
				message: '海拔服务异常: ' + error.message,
				data: null
			}
		}
	},

	/**
	 * 获取路径沿线的海拔信息
	 * @param {Object} params
	 * @param {Array} params.path - 路径顶点列表 [{lat: 36.579, lng: -118.292}, ...]
	 * @param {Number} params.samples - 采样点数量
	 */
	async getElevationAlongPath(params) {
		console.log('[海拔云函数] 开始获取路径海拔信息:', params)
		
		try {
			const { path = [], samples = 10 } = params
			
			if (!Array.isArray(path) || path.length < 2) {
				return {
					code: 400,
					message: '路径至少需要包含2个点',
					data: null
				}
			}
			
			if (samples < 2 || samples > 512) {
				return {
					code: 400,
					message: '采样点数量必须在2-512之间',
					data: null
				}
			}
			
			// 验证路径数据格式
			for (let i = 0; i < path.length; i++) {
				const point = path[i]
				if (!point.lat || !point.lng) {
					return {
						code: 400,
						message: `路径点 ${i + 1} 的经纬度格式不正确`,
						data: null
					}
				}
			}
			
					// 获取Google Maps API Key (使用uni-config-center)
		const createConfig = require('uni-config-center')
		const elevationConfig = createConfig({
			pluginId: 'a-elevation',
			defaultConfig: {
				googleMapsApiKey: 'AIzaSyC7HihytH-JPVOtshAWcd-6-cpPFT7Y3M4'
			}
		})
		
		const apiKey = elevationConfig.config('googleMapsApiKey')
		
		if (!apiKey) {
			console.error('[海拔云函数] Google Maps API Key未配置')
			return {
				code: 500,
				message: '海拔服务配置错误',
				data: null
			}
		}
		
		// 构建路径参数字符串
			const pathParam = path.map(point => `${point.lat},${point.lng}`).join('|')
			
			// 构建请求URL
			const url = `https://maps.googleapis.com/maps/api/elevation/json?path=${pathParam}&samples=${samples}&key=${apiKey}`
			console.log('[海拔云函数] 请求URL:', url.replace(apiKey, '***'))
			
			// 发起HTTP请求
			const response = await uniCloud.httpclient.request(url, {
				method: 'GET',
				timeout: 15000,
				dataType: 'json'
			})
			
			console.log('[海拔云函数] API响应状态:', response.status)
			console.log('[海拔云函数] API响应数据:', response.data)
			
			if (response.status !== 200) {
				console.error('[海拔云函数] API请求失败，状态码:', response.status)
				return {
					code: 500,
					message: '海拔服务请求失败',
					data: null
				}
			}
			
			const elevationData = response.data
			
			// 检查API返回状态
			if (elevationData.status !== 'OK') {
				console.error('[海拔云函数] Google API返回错误:', {
					status: elevationData.status,
					error_message: elevationData.error_message
				})
				return {
					code: 500,
					message: this.getErrorMessage(elevationData.status),
					data: {
						status: elevationData.status,
						error_message: elevationData.error_message,
						originalError: elevationData
					}
				}
			}
			
			// 格式化海拔数据
			const formattedData = this.formatElevationData(elevationData.results, 'path', {
				originalPath: path,
				samples: samples
			})
			
			console.log('[海拔云函数] 格式化后的数据:', formattedData)
			
			return {
				code: 200,
				message: '获取成功',
				data: formattedData
			}
			
		} catch (error) {
			console.error('[海拔云函数] 获取路径海拔信息失败:', error)
			return {
				code: 500,
				message: '海拔服务异常: ' + error.message,
				data: null
			}
		}
	},

	/**
	 * 批量获取多个位置组的海拔信息
	 * @param {Object} params
	 * @param {Array} params.locationGroups - 位置组列表
	 */
	async getBatchElevation(params) {
		console.log('[海拔云函数] 批量获取海拔信息:', params)
		
		try {
			const { locationGroups = [] } = params
			
			if (!Array.isArray(locationGroups) || locationGroups.length === 0) {
				return {
					code: 400,
					message: '位置组列表不能为空',
					data: null
				}
			}
			
			// 限制批量查询数量
			if (locationGroups.length > 5) {
				return {
					code: 400,
					message: '批量查询组数不能超过5个',
					data: null
				}
			}
			
			const results = []
			
			// 并发请求所有位置组的海拔
			const promises = locationGroups.map(async (group, index) => {
				try {
					const result = await this.getElevationForLocations({ locations: group.locations })
					return {
						groupName: group.name || `组${index + 1}`,
						...result
					}
				} catch (error) {
					console.error(`[海拔云函数] 获取组${index + 1}海拔失败:`, error)
					return {
						groupName: group.name || `组${index + 1}`,
						code: 500,
						message: '获取失败',
						data: null
					}
				}
			})
			
			const elevationResults = await Promise.all(promises)
			
			return {
				code: 200,
				message: '批量获取完成',
				data: elevationResults
			}
			
		} catch (error) {
			console.error('[海拔云函数] 批量获取海拔失败:', error)
			return {
				code: 500,
				message: '批量海拔服务异常: ' + error.message,
				data: null
			}
		}
	},

	/**
	 * 格式化海拔数据
	 * @param {Array} results - Google API返回的原始数据
	 * @param {String} type - 请求类型 locations/path
	 * @param {Object} extra - 额外信息
	 */
	formatElevationData(results, type, extra = {}) {
		console.log('[海拔云函数] 开始格式化海拔数据')
		
		try {
			const formattedResults = results.map((result, index) => {
				return {
					location: {
						lat: result.location.lat,
						lng: result.location.lng
					},
					elevation: Math.round(result.elevation * 100) / 100, // 保留2位小数
					resolution: result.resolution || null,
					formatted: {
						elevation: `${Math.round(result.elevation)}米`,
						elevationText: result.elevation >= 0 ? 
							`海拔${Math.round(result.elevation)}米` : 
							`海平面下${Math.abs(Math.round(result.elevation))}米`,
						coordinates: `${result.location.lat.toFixed(6)}, ${result.location.lng.toFixed(6)}`,
						resolution: result.resolution ? `精度${Math.round(result.resolution)}米` : '精度未知'
					}
				}
			})
			
			const baseData = {
				type: type,
				count: results.length,
				results: formattedResults
			}
			
			if (type === 'path') {
				// 路径类型的额外信息
				const elevations = formattedResults.map(r => r.elevation)
				const maxElevation = Math.max(...elevations)
				const minElevation = Math.min(...elevations)
				const elevationGain = maxElevation - minElevation
				
				baseData.pathInfo = {
					originalPath: extra.originalPath,
					samples: extra.samples,
					maxElevation: Math.round(maxElevation * 100) / 100,
					minElevation: Math.round(minElevation * 100) / 100,
					elevationGain: Math.round(elevationGain * 100) / 100,
					formatted: {
						maxElevation: `最高${Math.round(maxElevation)}米`,
						minElevation: `最低${Math.round(minElevation)}米`,
						elevationGain: `高差${Math.round(elevationGain)}米`
					}
				}
			} else {
				// 位置类型的额外信息
				baseData.locationInfo = {
					totalLocations: results.length,
					averageElevation: Math.round(
						formattedResults.reduce((sum, r) => sum + r.elevation, 0) / results.length * 100
					) / 100
				}
			}
			
			return baseData
			
		} catch (error) {
			console.error('[海拔云函数] 格式化海拔数据失败:', error)
			throw error
		}
	},

	/**
	 * 获取错误信息
	 * @param {String} status - API返回的状态码
	 */
	getErrorMessage(status) {
		const errorMessages = {
			'INVALID_REQUEST': '请求格式无效',
			'OVER_QUERY_LIMIT': '查询次数超出限制',
			'REQUEST_DENIED': '请求被拒绝，请检查API密钥',
			'UNKNOWN_ERROR': '未知错误，请稍后重试'
		}
		
		return errorMessages[status] || '海拔服务异常'
	}
} 