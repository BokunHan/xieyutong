'use strict';
exports.main = async (event, context) => {
	/**
	 * 根据搜索记录,设定时间间隔来归纳出热搜数据并存储在热搜表中
	 */
	const SEARCHHOT = 'a-search-hot'; // 热搜数据库名称
	const SEARCHLOG = 'a-search-log'; // 搜索记录数据库名称
	const SEARCHLOG_timeZone = 604800000; // 归纳搜索记录时间间隔，毫秒数，默认为最近7天
	const SEARCHHOT_size = 15; //	热搜条数

	const DB = uniCloud.database();
	const DBCmd = DB.command;
	const $ = DB.command.aggregate;
	const SEARCHHOT_db = DB.collection(SEARCHHOT);
	const SEARCHLOG_db = DB.collection(SEARCHLOG);
	const timeEnd = Date.now() - SEARCHLOG_timeZone;

	try {
		// 查询最近7天的搜索记录，按内容分组统计
		let {
			data: searchHotData
		} = await SEARCHLOG_db
			.aggregate()
			.match({
				create_date: DBCmd.gt(timeEnd)
			})
			.group({
				_id: {
					'content': '$content',
				},
				count: $.sum(1),
				recent_search: $.max('$create_date') // 最近搜索时间
			})
			.replaceRoot({
				newRoot: $.mergeObjects(['$_id', '$$ROOT'])
			})
			.project({
				_id: false
			})
			.sort({
				count: -1,
				recent_search: -1
			})
			.limit(SEARCHHOT_size)
			.end();

		if (!searchHotData.length) {
			console.log('没有搜索记录，跳过热搜更新');
			return { success: true, message: '没有搜索记录' };
		}

		// 清空旧的热搜数据
		await SEARCHHOT_db.where({}).remove();

		// 生成新的热搜数据
		let now = Date.now();
		const processedData = searchHotData.map((item, index) => {
			// 计算趋势（这里简化处理，实际可以对比历史数据）
			let trend = 'stable';
			if (index < 3) trend = 'up'; // 前3名标记为上升
			if (item.count === 1) trend = 'new'; // 只搜索过1次的标记为新

			return {
				content: item.content,
				count: item.count,
				rank: index + 1,
				trend: trend,
				category: getCategoryByContent(item.content), // 根据内容判断分类
				search_volume_7d: item.count,
				search_volume_30d: item.count, // 简化处理，实际应该查询30天数据
				related_products: [], // 暂时为空，后续可以根据搜索内容匹配相关产品
				create_date: now
			};
		});

		// 插入新的热搜数据
		const result = await SEARCHHOT_db.add(processedData);
		
		console.log(`热搜更新完成，共生成 ${processedData.length} 条热搜数据`);
		return { 
			success: true, 
			message: `热搜更新完成，共生成 ${processedData.length} 条热搜数据`,
			data: processedData
		};

	} catch (error) {
		console.error('热搜更新失败:', error);
		return { 
			success: false, 
			error: error.message 
		};
	}
};

/**
 * 根据搜索内容判断分类
 */
function getCategoryByContent(content) {
	// 目的地关键词
	const destinations = ['拉萨', '林芝', '山南', '阿里', '那曲', '昌都', '日喀则'];
	// 景点关键词
	const attractions = ['布达拉宫', '大峡谷', '雅鲁藏布', '南迦巴瓦', '羊卓雍措', '纳木措', '巴松措', '珠峰', '冈仁波齐', '鲁朗'];
	// 产品类型关键词
	const productTypes = ['私家团', '跟团', '自由行', '定制', '包车'];
	// 路线关键词
	const routes = ['环线', '深度游', '精品游'];

	if (destinations.some(dest => content.includes(dest))) {
		return 'destination';
	}
	if (attractions.some(attr => content.includes(attr))) {
		return 'attraction';
	}
	if (productTypes.some(type => content.includes(type))) {
		return 'product_type';
	}
	if (routes.some(route => content.includes(route))) {
		return 'route';
	}
	
	return 'general';
}
